# jQuery-Hamburger-Menu
This jQuery hamburger menu closes when you click outside the icon
